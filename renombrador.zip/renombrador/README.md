# Renombrador de Retenciones

App web para renombrar comprobantes de retención PDF automáticamente usando IA.

**Formato del nombre generado:** `emisor_tipo-retencion_fecha.pdf`

---

## Estructura del proyecto

```
renombrador/
├── api/
│   └── analyze.js      ← Backend (Vercel serverless function)
├── public/
│   └── index.html      ← Frontend
├── vercel.json         ← Configuración de Vercel
└── README.md
```

## Deploy en Vercel

1. Subí esta carpeta a un repositorio de GitHub
2. Entrá a [vercel.com](https://vercel.com) y conectá el repo
3. En la configuración del proyecto, agregá la variable de entorno:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** tu API key de Anthropic (obtenela en console.anthropic.com)
4. Deploy → listo, Vercel te da el link público
